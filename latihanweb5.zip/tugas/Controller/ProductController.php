<?php

namespace Controller;

include "Traits/ApiResponseFormatter.php";
include "Models/Product.php";

use Models\Product;
use Traits\ApiResponseFormatter;

class ProductController
{
    // PAKAI TRAIT YANG SUDAH DIBUAT
    use ApiResponseFormatter;

    public function users()
    {
        // DEFINISIKAN OBJECT MODEL PRODUCT YANG SUDAH DIBUAT
        $productModel = new Product();
        // PANGGIL FUNGSI GET ALL PRODUCT
        $response = $productModel->AllUser();
        // RETURN $response DENGAN MELAKUKAN FORMATTING TERLEBIH DAHULU MENGGUNAKAN TRAIT YANG SUDAH DIPANGGIL
        return $this->apiResponse(200, "success", $response);
    }

    public function posts()
    {
        // DEFINISIKAN OBJECT MODEL PRODUCT YANG SUDAH DIBUAT
        $productModel = new Product();
        // PANGGIL FUNGSI GET ALL PRODUCT
        $response = $productModel->AllPost();
        // RETURN $response DENGAN MELAKUKAN FORMATTING TERLEBIH DAHULU MENGGUNAKAN TRAIT YANG SUDAH DIPANGGIL
        return $this->apiResponse(200, "success", $response);
    }

    public function getUserById($id)
    {
        $productModel = new Product();
        $response = $productModel->UserById($id);
        return $this->apiResponse(200, "success", $response);
    }

    public function getPostById($id)
    {
        $productModel = new Product();
        $response = $productModel->PostById($id);
        return $this->apiResponse(200, "success", $response);
    }

    public function insertUser()
    {
        // TANGKAP INPUT JSON
        $jsonInput = file_get_contents('php://input');
        $inputData = json_decode($jsonInput, true);
        // VALIDASI APAKAH INPUT VALID
        if (json_last_error()) {
            return $this->apiResponse(400, "error invalid input", null);
        }

        // LANJUT JIKA TIDAK ERROR
        $productModel = new Product();
        $response = $productModel->createUser([
            "username" => $inputData['username'],
            "email" => $inputData['email']
        ]);
        return $this->apiResponse(200, "success", $response);
    }

    public function insertPost()
    {
        // TANGKAP INPUT JSON
        $jsonInput = file_get_contents('php://input');
        $inputData = json_decode($jsonInput, true);
        // VALIDASI APAKAH INPUT VALID
        if (json_last_error()) {
            return $this->apiResponse(400, "error invalid input", null);
        }

        // LANJUT JIKA TIDAK ERROR
        $productModel = new Product();
        $response = $productModel->createPost([ // Ganti ke createPosts
            "title" => $inputData['title'],
            "content" => $inputData['content'],
            "userId" => $inputData['userId']
        ]);
        return $this->apiResponse(200, "success", $response);
    }


    public function updateUser($id)
    {
        // TANGKAP INPUT JSON
        $jsonInput = file_get_contents('php://input');
        $inputData = json_decode($jsonInput, true);
        // VALIDASI APAKAH INPUT VALID
        if (json_last_error()) {
            return $this->apiResponse(400, "error invalid input", null);
        }

        // LANJUT JIKA TIDAK ERROR
        $productModel = new Product();
        $response = $productModel->updateUser([
            "username" => $inputData['username'],
            "email" => $inputData['email']
        ], $id);

        return $this->apiResponse(200, "success", $response);
    }

    public function updatePost($id) // Mengambil parameter ID
    {
        // TANGKAP INPUT JSON
        $jsonInput = file_get_contents('php://input');
        $inputData = json_decode($jsonInput, true);
        // VALIDASI APAKAH INPUT VALID
        if (json_last_error()) {
            return $this->apiResponse(400, "error invalid input", null);
        }

        // LANJUT JIKA TIDAK ERROR
        $productModel = new Product();
        $response = $productModel->updatePost([ // Ganti ke updatePost
            "title" => $inputData['title'],
            "content" => $inputData['content'],
            "userId" => $inputData['userId']
        ], $id); // Mengirimkan ID ke method updatePost

        return $this->apiResponse(200, "success", $response);
    }


    public function deleteUser($id)
    {
        $productModel = new Product();
        $response = $productModel->destroyUser($id);

        return $this->apiResponse(200, "success", $response);
    }

    public function deletePost($id)
    {
        $productModel = new Product();
        $response = $productModel->destroyPost($id);

        return $this->apiResponse(200, "success", $response);
    }
}
