<?php

namespace Models;

include "Config/DatabaseConfig.php";

use Config\DatabaseConfig;
use mysqli;

class Product extends DatabaseConfig
{
    public $conn;

    public function __construct()
    {
        // CONNECT KE DATABASE MYSQL
        $this->conn = new mysqli($this->host, $this->user, $this->password, $this->database_name, $this->port);
        // Check connection
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    // PROSES MENAMPILKAN SEMUA DATA
    public function AllUser()
    {
        $sql = "SELECT * FROM users";
        $result = $this->conn->query($sql);
        $this->conn->close();
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        return $data;
    }

    public function AllPost()
    {
        $sql = "SELECT posts.id, posts.title, posts.content, users.username
        FROM posts
        INNER JOIN users ON posts.userId = users.id";
        $result = $this->conn->query($sql);
        $this->conn->close();
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        return $data;
    }

    // PROSES MENAMPILAN DATA DENGAN ID
    public function UserById($id)
    {
        $sql = "SELECT * FROM users WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $this->conn->close();
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        return $data;
    }

    public function PostById($id)
    {
        $sql = "SELECT posts.id, posts.title, posts.content, users.username
        FROM posts
        INNER JOIN users ON posts.userId = users.id WHERE posts.id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $this->conn->close();
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        return $data;
    }
    // PROSES INSERT DATA
    public function createUser($data)
    {
        $username = $data['username'];
        $email = $data['email'];
        $query = "INSERT INTO users (username, email) VALUES (?, ?)";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ss", $username, $email); // Menggunakan "ss" karena keduanya string
        $stmt->execute();
        $stmt->close(); // Menutup statement
        $this->conn->close();
    }


    public function createPost($data)
    {
        $title = $data['title'];
        $content = $data['content'];
        $userId = $data['userId'];
        $query = "INSERT INTO posts (title, content, userId) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ssi", $title, $content, $userId);
        $stmt->execute();
        $this->conn->close();
    }

    // PROSES UPDATE DATA DENGAN ID
    public function updateUser($data, $id)
    {
        $username = $data['username'];
        $email = $data['email'];

        $query = "UPDATE users SET username = ?, email = ? WHERE id = ?";
        $stmt = $this->conn->prepare($query);

        $stmt->bind_param("ssi", $username, $email, $id);
        $stmt->execute();
        $this->conn->close();
    }

    public function updatePost($data, $id)
    {
        $title = $data['title'];
        $content = $data['content'];
        $userId = $data['userId'];

        $query = "UPDATE posts SET title = ?, content = ?, userId = ? WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ssii", $title, $content, $userId, $id);
        $stmt->execute();
        $this->conn->close();
    }

    // PROSES DELETE DATA DENGAN ID
    public function destroyUser($id)
    {
        $query = "DELETE FROM users WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        // huruf "i" berarti parameter pertama adalah integer
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $this->conn->close();
    }

    public function destroyPost($id)
    {
        $query = "DELETE FROM posts WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        // huruf "i" berarti parameter pertama adalah integer
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $this->conn->close();
    }
}
