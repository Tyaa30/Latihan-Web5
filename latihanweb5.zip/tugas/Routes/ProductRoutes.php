<?php

namespace Routes;

include "Controller/ProductController.php";

use Controller\ProductController;

class ProductRoutes
{
    public function handle($method, $path)
    {
        if ($method === 'GET' && $path === '/api/users') {
            $controller = new ProductController();
            echo $controller->users();
        }

        if ($method === 'GET' && $path === '/api/posts') {
            $controller = new ProductController();
            echo $controller->posts();
        }

        // JIKA REQUEST METHOD GET DAN PATH MENGANDUNG '/api/product/'
        if ($method === 'GET' && strpos($path, '/api/users/') === 0) {
            // Extract ID dari path
            $pathParts = explode('/', $path);
            $id = $pathParts[count($pathParts) - 1];

            $controller = new ProductController();
            echo $controller->getUserById($id);
        }

        if ($method === 'GET' && strpos($path, '/api/posts/') === 0) {
            // Extract ID dari path
            $pathParts = explode('/', $path);
            $id = $pathParts[count($pathParts) - 1];

            $controller = new ProductController();
            echo $controller->getPostById($id);
        }

        // JIKA REQUEST METHOD POST DAN PATH SAMA DENGAN '/api/product'
        if ($method === 'POST' && $path === '/api/users') {
            $controller = new ProductController();
            echo $controller->insertUser();
        }

        if ($method === 'POST' && $path === '/api/posts') { // Ubah path
            $controller = new ProductController();
            echo $controller->insertPost(); // Ganti ke insertPost
        }        

        // JIKA REQUEST METHOD PUT DAN PATH MENGANDUNG '/api/product/'
        if ($method === 'PUT' && strpos($path, '/api/users/') === 0) {
            // Extract ID dari path
            $pathParts = explode('/', $path);
            $id = $pathParts[count($pathParts) - 1];

            $controller = new ProductController();
            echo $controller->updateUser($id);
        }

        if ($method === 'PUT' && strpos($path, '/api/posts/') === 0) {
            // Extract ID dari path
            $pathParts = explode('/', $path);
            $id = $pathParts[count($pathParts) - 1];
        
            $controller = new ProductController();
            echo $controller->updatePost($id); // Mengirimkan ID ke method updatePost
        }

        // JIKA REQUEST METHOD DELETE DAN PATH MENGANDUNG '/api/product/'
        if ($method === 'DELETE' && strpos($path, '/api/users/') === 0) {
            // Extract ID dari path
            $pathParts = explode('/', $path);
            $id = $pathParts[count($pathParts) - 1];

            $controller = new ProductController();
            echo $controller->deleteUser($id);
        }

        if ($method === 'DELETE' && strpos($path, '/api/posts/') === 0) {
            // Extract ID dari path
            $pathParts = explode('/', $path);
            $id = $pathParts[count($pathParts) - 1];

            $controller = new ProductController();
            echo $controller->deletePost($id);
        }
    }
}
